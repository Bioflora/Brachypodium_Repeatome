###### TO CONDUCT PHYLOGENETIC ANALYSES ######

# Starting 342 top clusters
# 46/342 organelle clusters
# 280/342 clusters with NA or zero
# Final valid nuclear clusters: 55

# 1) Extract file with all the "comparative analysis - observed/expected number of edges between species" for each cluster:

## Use in-house script (by M.F. Moreno-Aguilar) "parse_re2_matrix.pl" (Edited).
according to your sample codes and path.
## Run: perl parse_re2_matrix.pl

# 2) Change format and name

mv ratios_file.txt original_ratios_file.txt

## we use tr command along with squeeze option (-s flag ) to convert all multiple consecutive spaces to a single space

cat original_ratios_file.txt | tr -s ' ' > ratios_file.txt

# 3) Extract each matrix (see matrices folder)

## Edit script.

see bash script: bash extract_matrix.sh

# 4) Remove first column (cluster ID)

for cluster in *tmp.txt; do cut -d' ' -f2- $cluster > $cluster.format.txt; done

# 5) Find clusters (matrices) with NAs or zeros (they have to be removed)

grep -w -e "0.000" -e "NA" *.format.txt | cut -d ':' -f1 | uniq > list_clusters_discarded.txt

## 280 removed

# List all cluster files

ls -1 *.txt.format.txt > list_all_clusters.txt

## Compare both lists to extract the "list_good_clusters.txt"

comm -23  <((sort list_all_clusters.txt)) <((sort list_clusters_discarded.txt)) > list_good_clusters.txt

## 62 "good clusters" (I have to check the organelle clusters for removing downstream)

# 6) Copy clusters to new folder

xargs -a list_good_clusters.txt cp -t good_clusters/

## IMPORTANT: Check "good clusters" and discard (move to folder "organelle_clusters") the organelle clusters

## Oraganelle cluster: 46 clusters 

## Create list of organelle cluster and move them to the folder organelle_clusters

xargs -a list_organelle_cluster.txt mv -t organelle_clusters

## Final good clusters:  nuclear repetitive cluster with all samples
## 55 clusters

# 7) Compute inverse values

for cluster in *.format.txt; do awk -v c=-1 '{ for (i = 1; i <= NF; ++i) $i ^=c; print }' OFS=' ' $cluster > $cluster.inverse.txt; done

## Rounding floating number (three decimals):

for cluster in *.inverse.txt; do awk '{for (i=1; i<=NF; i++) printf "%.3f %s", $i, (i==NF?"\n":" ")}' $cluster > $cluster.final.txt; done

# 8) Convert txt to csv (;)

for cluster in *.final.txt; do cat $cluster | tr -s '[:blank:]' ';' > $cluster.csv; done

## Remove the last ";" for each line:

for cluster in *.final.txt.csv; do cat $cluster | sed 's/.$//' > $cluster.format.csv; done

# 9) Prepare header file to add to the matrix

## According to the abbreviations:

'AA','AC','AD','AB','AE','AF','AG','AH','AI','AK','AL','AM','AN','AO','AP','AQ','AS','AT','AR','AU','AV','AW','AX','AY','AZ','BA','BC','BD','BE','BF','BG','BH','BI','BJ','BL','BP','BX','BY','MB','MD','MC','DA','SA','HA'

## Final header:
Copy in file "header.csv"

"B.arbuscula_502";"B.boissieri_10";"B.boissieri_15";"B.boissieri_3";"B.phoenicoides_422";"B.phoenicoides_452";"B.phoenicoides_552";"B.phoenicoides_553";"B.phoenicoides_554-1";"B.phoenicoides_6-1R";"B.pinnatum_34";"B.pinnatum_505";"B.pinnatum_514";"B.pinnatum_520";"B.retusum_400";"B.retusum_403";"B.retusum_407";"B.retusum_408";"B.retusum_453-4";"B.retusum_454";"B.retusum_504";"B.retusum_551";"B.retusum_555";"B.retusum_557";"B.retusum_561";"B.rupestre_182";"B.rupestre_439-1";"B.rupestre_441";"B.rupestre_442";"B.rupestre_443";"B.rupestre_444";"B.rupestre_600";"B.rupestre_605";"B.rupestre_7";"B.sylvaticum_466-6";"B.sylvaticum_477-1";"B.sylvaticum_501-6";"B.sylvaticum_54-1";"B.mexicanum_504";"B.mexicanum_347-2";"B.mexicanum_Puebla";"B.distachyon_Bd21-3";"B.stacei_ABR114";"B.hybridum_ABR113"

for cluster in *.final.txt.csv.format.csv; do cat header.csv $cluster > $cluster.header.csv; done

# 10) Rename files

for cluster in *.inverse.txt.final.txt.csv.format.csv.header.csv; do mv "$cluster"  "$(basename "$cluster" _tmp.txt.format.txt.inverse.txt.final.txt.csv.format.csv.header.csv)_inverse.csv"; done

# 11) To get phylogeny run:

sampling_v4_phylogeny.Rmd

